package domein;

public class Moderator extends Role
	{

		public Moderator(boolean hasPermissions)
			{
				super(hasPermissions);
			}
	}
