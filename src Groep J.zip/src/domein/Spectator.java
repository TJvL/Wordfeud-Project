package domein;

public class Spectator extends Role
	{
		public Spectator(boolean hasPermissions)
			{
				super(hasPermissions);
			}
	}
