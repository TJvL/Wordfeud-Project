package domein;

import datalaag.DatabaseHandler;

public class Statistics {
	
	
	private DatabaseHandler dbh;
	private String gamesWonString;
	private String playedGamesString;
	private String compsWonString;
	private String highScoreString;
	
	public Statistics()
	{
		
		dbh = DatabaseHandler.getInstance();
	}
	
	public void retrieveData(String userName)
	{
		String dataBefore = dbh.playerStatistics(userName);
		
		String[] dataAfter = dataBefore.split("---");

		compsWonString = dataAfter[0];
		gamesWonString = dataAfter[1];
		playedGamesString = dataAfter[4];
		highScoreString = dataAfter[5];		
	}

	public String getGamesWonString()
	{
		return gamesWonString;
	}

	public String getPlayedGamesString()
	{
		return playedGamesString;
	}

	public String getCompsWonString()
	{
		return compsWonString;
	}

	public String getHighScoreString()
	{
		return highScoreString;
	}
	
	

}
