package gui;

import javax.swing.JDialog;

@SuppressWarnings("serial")
public class AdminCompWindow extends JDialog{

//	private JPanel listPanel;
//	private int compID;
//	private User currentUser;
//	
//	public AdminCompWindow(MainFrame mainFrame)
//	{
//		this.setTitle("Competition Participants");	
//		this.setLayout(new BorderLayout());
//		this.setPreferredSize(new Dimension(400,600));
//		this.setResizable(false);
////		createListField();
////		createJRadioButtonPanel();
////		createButtons();
//		
//		this.setModal(true);
//							
////		this.add(dataField, BorderLayout.NORTH);
////		this.add(radioButtonPanel, BorderLayout.CENTER);
////		this.add(buttons, BorderLayout.SOUTH);
//		this.pack();
//		this.setLocationRelativeTo(mainFrame);
//		this.setVisible(true);
//	}
//	
//	public void createListField()
//	{
//		listPanel = new JPanel();
//		listPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));	
//		System.out.println(getCompID());
//		ArrayList<String> participantArray = currentUser.getAdmin().adminCompetitionParticipants(getCompID());
//		JList participantList = new JList(participantArray.toArray());
//		
//	}
//
//	public int getCompID()
//	{
//		return compID;
//	}
//
//	public void setCompID(int compID)
//	{
//		this.compID = compID;
//		System.out.println(compID);
//	}
	
}
